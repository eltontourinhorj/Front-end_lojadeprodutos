import React, { useState } from 'react';
import axios from "axios";
import Button from 'react-bootstrap/Button';
import Form from 'react-bootstrap/Form';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';


function FormAdd() {
  const [formValues] = useState();

  const handleSubmit  = (event) =>  {axios.post('http://127.0.0.1:5000/cadastrar_produto', formValues); event.preventDefault();};
  return (
    <Form onSubmit={handleSubmit }>
      <h4>Adicionar Produto</h4>
      <Row className="mb-3">
        <Form.Group as={Col} className="mb-3" controlId="formBasicEmail">

          <Form.Control type="text" placeholder="Nome" />
        </Form.Group>
        <Form.Group as={Col} className="mb-3" controlId="formBasicPassword">

          <Form.Control type="text" placeholder="Descrição" />
        </Form.Group>
        <Form.Group as={Col} className="mb-3" controlId="formBasicPassword">

          <Form.Control type="number" placeholder="Preço" />
        </Form.Group>
        <Button type='submit'  variant="primary">
          Adicionar
        </Button>
      </Row>
    </Form>
  );
}

export default FormAdd;