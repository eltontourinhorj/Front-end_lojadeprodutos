import React, { useState, useEffect } from 'react';
import axios from "axios";
import Table from 'react-bootstrap/Table';
import Button from 'react-bootstrap/Button';
import FormAdd from './FormAdd';



const Tabela = () => {

    const [products, setProducts] = useState([]);
    const [error, setError] = useState(null);

    useEffect(() => {
        axios.get('http://localhost:5000/buscar_produtos/')
            .then(res => setProducts(res.data))
            .catch(err => setError(err));
    }, []);

    const handleDelete = (productId) => {
        axios.delete('http://127.0.0.1:5000/deletar_produto/', { data: { id: productId } })
            .then(res => {
                const updatedProducts = products.filter(product => product.id !== productId);
                setProducts(updatedProducts);
            })
            .catch(err => setError(err));
    };

    const allProducts = products || [];

    // const produtos = () => axios.get('http://localhost:5000/buscar_produtos/').then(res => { setProducts(res.data) })
    //const idproduto = () => axios.get('http://127.0.0.1:5000/buscar_produto/', { data: { id: produtoId } }).then(res => { setProducts(res.data) })
    //const addProduto = () => axios.post('http://127.0.0.1:5000/cadastrar_produto', produto).then(res => { setProducts(res.data) })


    return (
        <>
            <Table striped>
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Nome do Produto</th>
                        <th>Descrição</th>
                        <th>Preco</th>
                    </tr>
                </thead>
                <tbody>
                    {allProducts?.length > 0 ? (
                        allProducts.map((character, index) => (
                            <tr key={index} character={character}>
                                <td>{character.id}</td>
                                <td>{character.nome}</td>
                                <td>{character.descricao}</td>
                                <td>{character.preco}</td>
                                <td> <Button onClick={() => handleDelete(character.id)}>
                                    Excluir
                                </Button></td>
                            </tr>
                        ))
                    ) : (
                        <tr>
                            <td colSpan="1">No products found.</td>
                        </tr>
                    )}
                </tbody>
            </Table>
            <FormAdd/>
        </>
    )

}

export default Tabela