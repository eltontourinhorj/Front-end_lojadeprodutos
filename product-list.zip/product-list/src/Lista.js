import React, { Component } from 'react';
import Tabela from './Tabela';


class Lista extends Component {
    render() {


        return (
            <div>
                <Tabela />
            </div>
        )
    }
}

export default Lista;